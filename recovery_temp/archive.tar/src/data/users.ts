import { User } from '../types';

export const users: User[] = [
    {
        id: '1',
        name: 'Hoang Minh',
        email: 'hoangminh@example.com',
    },
    {
        id: '2',
        name: 'Jane Doe',
        email: 'janedoe@example.com',
    },
];
